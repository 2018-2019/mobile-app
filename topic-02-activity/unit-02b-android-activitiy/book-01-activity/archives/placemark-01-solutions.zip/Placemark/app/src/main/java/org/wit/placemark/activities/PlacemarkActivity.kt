package org.wit.placemark.activities

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_placemark.*
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info
import org.jetbrains.anko.toast
import org.wit.placemark.R
import org.wit.placemark.models.PlacemarkModel

class PlacemarkActivity : AppCompatActivity(), AnkoLogger {

    val placemarks = ArrayList<PlacemarkModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_placemark)

        btnAdd.setOnClickListener() {
            val placemarkEntered = placemarkTitle.text.toString()
            val descEntered = placemarkDescription.text.toString()
            if (placemarkEntered.isNotEmpty() && descEntered.isNotEmpty()) {
                info("Add Button Pressed. name: $placemarkEntered desc: $descEntered")
                placemarks.add(PlacemarkModel(placemarkEntered, descEntered))
                placemarks.forEach { info("Placemarks: ${it.title}")}
            }
            else {
                toast ("Please enter a placemark desc and title")
            }
        }
    }
}
